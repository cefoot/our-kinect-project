require(['dojox/cometd', 'dojo/dom', 'dojo/dom-construct', 'dojo/domReady!'], function(cometd, dom, doc)
{
    cometd.configure({
        url: location.protocol + '//' + location.host + config.contextPath + '/cometd',
        logLevel: 'info'
    });

    cometd.addListener('/meta/handshake', function(message)
    	    {
    	        if (message.successful)
    	        {
    	            dom.byId('status').innerHTML += '<div>CometD handshake successful</div>';
    	            cometd.subscribe('/hello/world', function(message)
    	            		{
    	            			dom.byId('status').innerHTML += '<div>';
    	            			dom.byId('status').innerHTML += message.data;
    	            			dom.byId('status').innerHTML += '</div>';
    	            		});
    	        }
    	        else
    	        {
    	        	dom.byId('status').innerHTML += '<div>CometD handshake failed</div>';
    	        }
    	    });

    dom.byId('greeter').onclick = function()
    {
    	cometd.publish('/service/hello', 'Hello, World');
    	cometd.publish('/hello/world', 'Hello, World from da Button');
    };
    cometd.handshake();
});
